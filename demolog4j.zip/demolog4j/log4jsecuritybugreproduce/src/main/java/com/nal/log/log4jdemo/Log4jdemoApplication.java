package com.nal.log.log4jdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Log4jdemoApplication {

	public static void main(String[] args) {

		SpringApplication.run(Log4jdemoApplication.class, args);
	}

}
