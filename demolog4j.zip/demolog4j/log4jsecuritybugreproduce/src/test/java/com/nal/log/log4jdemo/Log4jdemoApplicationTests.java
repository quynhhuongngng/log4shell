package com.nal.log.log4jdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Log4jdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
